package com.restaurante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.restaurante")
@EnableJpaRepositories(basePackages = "com.restaurante.repository") // Fuerza el escaneo de repositorios
@EntityScan(basePackages = "com.restaurante.model") // Fuerza el escaneo de entidades
public class RestauranteBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(RestauranteBackendApplication.class, args);
    }
}