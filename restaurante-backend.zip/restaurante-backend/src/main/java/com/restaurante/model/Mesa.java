package com.restaurante.model;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity @Table(name = "Mesa") @Data @NoArgsConstructor
public class Mesa {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_mesa") private Long idMesa;
    @Column(name = "numero_mesa") private Integer numeroMesa;
    @Column(name = "capacidad") private Integer capacidad;
}
