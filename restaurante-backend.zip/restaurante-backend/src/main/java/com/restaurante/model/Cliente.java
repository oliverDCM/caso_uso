package com.restaurante.model;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity @Table(name = "Cliente") @Data @NoArgsConstructor
public class Cliente {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cliente") private Long idCliente;
    @Column(name = "nombre_cliente") private String nombreCliente;
    @Column(name = "telefono") private String telefono;
}
