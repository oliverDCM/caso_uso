package com.restaurante.model;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity @Table(name = "Menu") @Data @NoArgsConstructor
public class Menu {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_plato") private Long idPlato;
    @Column(name = "nombre_plato") private String nombrePlato;
    @Column(name = "precio") private Double precio;
    @Column(name = "categoria") private String categoria;
}
