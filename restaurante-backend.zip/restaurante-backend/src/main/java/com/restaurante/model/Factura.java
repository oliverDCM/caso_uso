package com.restaurante.model;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity @Table(name = "Factura") @Data @NoArgsConstructor
public class Factura {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_factura") private Long idFactura;
    @OneToOne @JoinColumn(name = "id_pedido") private Pedido pedido;
    @Column(name = "fecha") private LocalDateTime fecha;
    @Column(name = "metodo_pago") private String metodoPago;
    @Column(name = "total") private Double total;
}
