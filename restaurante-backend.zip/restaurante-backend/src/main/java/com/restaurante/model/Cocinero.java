package com.restaurante.model;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity @Table(name = "Cocinero") @Data @NoArgsConstructor
public class Cocinero {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cocinero") private Long idCocinero;
    @Column(name = "nombre_cocinero") private String nombreCocinero;
    @Column(name = "turno") private String turno;
}
