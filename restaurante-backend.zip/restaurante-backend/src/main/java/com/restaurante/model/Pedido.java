package com.restaurante.model;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity @Table(name = "Pedido") @Data @NoArgsConstructor
public class Pedido {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pedido") private Long idPedido;
    @ManyToOne @JoinColumn(name = "id_cliente") private Cliente cliente;
    @ManyToOne @JoinColumn(name = "id_mesa") private Mesa mesa;
    @ManyToOne @JoinColumn(name = "id_cocinero") private Cocinero cocinero;
    @Column(name = "fecha") private LocalDateTime fecha;
}
