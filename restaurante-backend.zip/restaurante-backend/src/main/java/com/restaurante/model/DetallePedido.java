package com.restaurante.model;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity @Table(name = "Detalle_Pedido") @Data @NoArgsConstructor
public class DetallePedido {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_detalle") private Long idDetalle;
    @ManyToOne @JoinColumn(name = "id_pedido") private Pedido pedido;
    @ManyToOne @JoinColumn(name = "id_plato") private Menu plato;
    @Column(name = "cantidad") private Integer cantidad;
}
