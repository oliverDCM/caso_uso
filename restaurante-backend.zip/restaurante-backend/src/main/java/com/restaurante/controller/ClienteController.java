package com.restaurante.controller;
import com.restaurante.model.Cliente;
import com.restaurante.service.ClienteService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/clientes") @RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class ClienteController {
    private final ClienteService service;
    @GetMapping public List<Cliente> listar() { return service.listarTodos(); }
    @PostMapping public Cliente crear(@RequestBody Cliente c) { return service.guardar(c); }
    @GetMapping("/{id}") public ResponseEntity<Cliente> buscar(@PathVariable Long id) {
        return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<Cliente> actualizar(@PathVariable Long id, @RequestBody Cliente c) {
        return service.buscarPorId(id).map(e -> { c.setIdCliente(id); return ResponseEntity.ok(service.guardar(c)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id); return ResponseEntity.noContent().build();
    }
}
