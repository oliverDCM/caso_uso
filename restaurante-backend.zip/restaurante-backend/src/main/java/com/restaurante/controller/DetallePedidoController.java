package com.restaurante.controller;
import com.restaurante.model.DetallePedido;
import com.restaurante.service.DetallePedidoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/detalles") @RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class DetallePedidoController {
    private final DetallePedidoService service;
    @GetMapping public List<DetallePedido> listar() { return service.listarTodos(); }
    @PostMapping public DetallePedido crear(@RequestBody DetallePedido d) { return service.guardar(d); }
    @GetMapping("/{id}") public ResponseEntity<DetallePedido> buscar(@PathVariable Long id) {
        return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<DetallePedido> actualizar(@PathVariable Long id, @RequestBody DetallePedido d) {
        return service.buscarPorId(id).map(e -> { d.setIdDetalle(id); return ResponseEntity.ok(service.guardar(d)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id); return ResponseEntity.noContent().build();
    }
}
