package com.restaurante.controller;
import com.restaurante.model.Menu;
import com.restaurante.service.MenuService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/menu") @RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class MenuController {
    private final MenuService service;
    @GetMapping public List<Menu> listar() { return service.listarTodos(); }
    @PostMapping public Menu crear(@RequestBody Menu m) { return service.guardar(m); }
    @GetMapping("/{id}") public ResponseEntity<Menu> buscar(@PathVariable Long id) {
        return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<Menu> actualizar(@PathVariable Long id, @RequestBody Menu m) {
        return service.buscarPorId(id).map(e -> { m.setIdPlato(id); return ResponseEntity.ok(service.guardar(m)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id); return ResponseEntity.noContent().build();
    }
}
