package com.restaurante.controller;
import com.restaurante.model.Mesa;
import com.restaurante.service.MesaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/mesas") @RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class MesaController {
    private final MesaService service;
    @GetMapping public List<Mesa> listar() { return service.listarTodos(); }
    @PostMapping public Mesa crear(@RequestBody Mesa m) { return service.guardar(m); }
    @GetMapping("/{id}") public ResponseEntity<Mesa> buscar(@PathVariable Long id) {
        return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<Mesa> actualizar(@PathVariable Long id, @RequestBody Mesa m) {
        return service.buscarPorId(id).map(e -> { m.setIdMesa(id); return ResponseEntity.ok(service.guardar(m)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id); return ResponseEntity.noContent().build();
    }
}
