package com.restaurante.controller;
import com.restaurante.model.Cocinero;
import com.restaurante.service.CocineroService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/cocineros") @RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class CocineroController {
    private final CocineroService service;
    @GetMapping public List<Cocinero> listar() { return service.listarTodos(); }
    @PostMapping public Cocinero crear(@RequestBody Cocinero c) { return service.guardar(c); }
    @GetMapping("/{id}") public ResponseEntity<Cocinero> buscar(@PathVariable Long id) {
        return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<Cocinero> actualizar(@PathVariable Long id, @RequestBody Cocinero c) {
        return service.buscarPorId(id).map(e -> { c.setIdCocinero(id); return ResponseEntity.ok(service.guardar(c)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id); return ResponseEntity.noContent().build();
    }
}
