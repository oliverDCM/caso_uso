package com.restaurante.controller;
import com.restaurante.model.Pedido;
import com.restaurante.service.PedidoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/pedidos") @RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class PedidoController {
    private final PedidoService service;
    @GetMapping public List<Pedido> listar() { return service.listarTodos(); }
    @PostMapping public Pedido crear(@RequestBody Pedido p) { return service.guardar(p); }
    @GetMapping("/{id}") public ResponseEntity<Pedido> buscar(@PathVariable Long id) {
        return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<Pedido> actualizar(@PathVariable Long id, @RequestBody Pedido p) {
        return service.buscarPorId(id).map(e -> { p.setIdPedido(id); return ResponseEntity.ok(service.guardar(p)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id); return ResponseEntity.noContent().build();
    }
}
