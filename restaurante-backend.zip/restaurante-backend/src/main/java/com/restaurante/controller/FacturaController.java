package com.restaurante.controller;
import com.restaurante.model.Factura;
import com.restaurante.service.FacturaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/facturas") @RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class FacturaController {
    private final FacturaService service;
    @GetMapping public List<Factura> listar() { return service.listarTodos(); }
    @PostMapping public Factura crear(@RequestBody Factura f) { return service.guardar(f); }
    @GetMapping("/{id}") public ResponseEntity<Factura> buscar(@PathVariable Long id) {
        return service.buscarPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<Factura> actualizar(@PathVariable Long id, @RequestBody Factura f) {
        return service.buscarPorId(id).map(e -> { f.setIdFactura(id); return ResponseEntity.ok(service.guardar(f)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id); return ResponseEntity.noContent().build();
    }
}
