package com.restaurante.service;
import com.restaurante.model.DetallePedido;
import com.restaurante.repository.DetallePedidoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service @RequiredArgsConstructor
public class DetallePedidoService {
    private final DetallePedidoRepository repository;
    public List<DetallePedido> listarTodos() { return repository.findAll(); }
    public DetallePedido guardar(DetallePedido d) { return repository.save(d); }
    public Optional<DetallePedido> buscarPorId(Long id) { return repository.findById(id); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
