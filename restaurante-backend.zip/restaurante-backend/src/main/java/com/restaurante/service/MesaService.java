package com.restaurante.service;
import com.restaurante.model.Mesa;
import com.restaurante.repository.MesaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service @RequiredArgsConstructor
public class MesaService {
    private final MesaRepository repository;
    public List<Mesa> listarTodos() { return repository.findAll(); }
    public Mesa guardar(Mesa m) { return repository.save(m); }
    public Optional<Mesa> buscarPorId(Long id) { return repository.findById(id); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
