package com.restaurante.service;
import com.restaurante.model.Cocinero;
import com.restaurante.repository.CocineroRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service @RequiredArgsConstructor
public class CocineroService {
    private final CocineroRepository repository;
    public List<Cocinero> listarTodos() { return repository.findAll(); }
    public Cocinero guardar(Cocinero c) { return repository.save(c); }
    public Optional<Cocinero> buscarPorId(Long id) { return repository.findById(id); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
