package com.restaurante.service;
import com.restaurante.model.Cliente;
import com.restaurante.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service @RequiredArgsConstructor
public class ClienteService {
    private final ClienteRepository repository;
    public List<Cliente> listarTodos() { return repository.findAll(); }
    public Cliente guardar(Cliente c) { return repository.save(c); }
    public Optional<Cliente> buscarPorId(Long id) { return repository.findById(id); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
