package com.restaurante.service;
import com.restaurante.model.Factura;
import com.restaurante.repository.FacturaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service @RequiredArgsConstructor
public class FacturaService {
    private final FacturaRepository repository;
    public List<Factura> listarTodos() { return repository.findAll(); }
    public Factura guardar(Factura f) { return repository.save(f); }
    public Optional<Factura> buscarPorId(Long id) { return repository.findById(id); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
