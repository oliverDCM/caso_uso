package com.restaurante.service;
import com.restaurante.model.Pedido;
import com.restaurante.repository.PedidoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service @RequiredArgsConstructor
public class PedidoService {
    private final PedidoRepository repository;
    public List<Pedido> listarTodos() { return repository.findAll(); }
    public Pedido guardar(Pedido p) { return repository.save(p); }
    public Optional<Pedido> buscarPorId(Long id) { return repository.findById(id); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
