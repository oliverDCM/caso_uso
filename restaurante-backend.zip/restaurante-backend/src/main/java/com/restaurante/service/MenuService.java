package com.restaurante.service;
import com.restaurante.model.Menu;
import com.restaurante.repository.MenuRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service @RequiredArgsConstructor
public class MenuService {
    private final MenuRepository repository;
    public List<Menu> listarTodos() { return repository.findAll(); }
    public Menu guardar(Menu m) { return repository.save(m); }
    public Optional<Menu> buscarPorId(Long id) { return repository.findById(id); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
