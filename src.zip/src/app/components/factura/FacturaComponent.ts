import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-factura',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './factura.html',
  styleUrls: ['./factura.css']
})
export class FacturaComponent implements OnInit {
  mesaABuscar: string = '';
  historicoFacturas: any[] = [];
  
  factura = {
    mesa: '',
    cliente: '',
    detalles: [] as any[],
    subtotal: 0,
    total: 0,
    fecha: ''
  };

  constructor(private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    this.cargarHistorico();
  }

  cargarHistorico() {
    const guardadas = localStorage.getItem('historico_facturas');
    if (guardadas) {
      this.historicoFacturas = JSON.parse(guardadas);
    }
  }

  buscarPedido() {
    const datosGuardados = JSON.parse(localStorage.getItem('pedidos_vivos') || '[]');
    const pedidoEncontrado = datosGuardados.find((p: any) => p.mesa == this.mesaABuscar);

    if (pedidoEncontrado) {
      this.factura.mesa = this.mesaABuscar;
      this.factura.detalles = [...pedidoEncontrado.platos];
      this.calcularTotales();
    } else {
      alert('No hay consumos para la Mesa ' + this.mesaABuscar);
      this.limpiarFormulario();
    }
    this.cdr.detectChanges();
  }

  calcularTotales() {
    this.factura.subtotal = this.factura.detalles.reduce((acc, item) => acc + (item.precio * item.cantidad), 0);
    this.factura.total = this.factura.subtotal * 1.19;
  }

  finalizarCobro() {
    if (this.factura.detalles.length > 0) {
      this.factura.fecha = new Date().toLocaleString();
      
      // 1. Guardar en el histórico
      this.historicoFacturas.unshift({ ...this.factura });
      localStorage.setItem('historico_facturas', JSON.stringify(this.historicoFacturas));

      // 2. Eliminar el pedido vivo (liberar mesa)
      let pedidosVivos = JSON.parse(localStorage.getItem('pedidos_vivos') || '[]');
      pedidosVivos = pedidosVivos.filter((p: any) => p.mesa != this.factura.mesa);
      localStorage.setItem('pedidos_vivos', JSON.stringify(pedidosVivos));

      alert('Cobro realizado y factura guardada');
      this.limpiarFormulario();
    }
  }

  limpiarFormulario() {
    this.factura = { mesa: '', cliente: '', detalles: [], subtotal: 0, total: 0, fecha: '' };
    this.mesaABuscar = '';
    this.cdr.detectChanges();
  }
}