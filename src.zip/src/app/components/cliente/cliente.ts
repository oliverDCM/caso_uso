import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClienteService, Cliente } from '../../services/cliente';

@Component({
  selector: 'app-cliente',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './cliente.html',
  styleUrls: ['./cliente.css']
})
export class ClienteComponent implements OnInit {
  clientes: Cliente[] = [];
  cliente: Cliente = { nombreCliente: '', telefono: '' };
  editando = false;
  idEditando?: number;

  constructor(
    private service: ClienteService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() { 
    this.cargar(); 
  }

  cargar() { 
    this.service.listar().subscribe({
      next: (data) => {
        this.clientes = [...data];
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }

  guardar() {
    if (this.editando && this.idEditando) {
      this.service.actualizar(this.idEditando, this.cliente).subscribe({
        next: () => {
          this.cargar(); 
          this.limpiar();
        }
      });
    } else {
      this.service.crear(this.cliente).subscribe({
        next: () => {
          this.cargar(); 
          this.limpiar();
        }
      });
    }
  }

  editar(c: Cliente) {
    this.cliente = { ...c };
    this.editando = true;
    this.idEditando = c.idCliente;
  }

  eliminar(id: number) {
    if (confirm('¿Eliminar cliente?')) {
      this.service.eliminar(id).subscribe({
        next: () => this.cargar()
      });
    }
  }

  limpiar() {
    this.cliente = { nombreCliente: '', telefono: '' };
    this.editando = false;
    this.idEditando = undefined;
    this.cdr.detectChanges();
  }
}