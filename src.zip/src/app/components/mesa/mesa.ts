import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MesaService, Mesa } from '../../services/mesa';

@Component({
  selector: 'app-mesa',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './mesa.html',
  styleUrls: ['./mesa.css']
})
export class MesaComponent implements OnInit {
  mesas: Mesa[] = [];
  mesa: Mesa = { numeroMesa: 0, capacidad: 0 };
  editando = false;
  idEditando?: number;

  constructor(
    private service: MesaService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.cargar();
  }

  cargar() {
    this.service.listar().subscribe({
      next: (data) => {
        this.mesas = [...data];
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }

  guardar() {
    if (this.editando && this.idEditando) {
      this.service.actualizar(this.idEditando, this.mesa).subscribe({
        next: () => {
          this.cargar();
          this.limpiar();
        }
      });
    } else {
      this.service.crear(this.mesa).subscribe({
        next: () => {
          this.cargar();
          this.limpiar();
        }
      });
    }
  }

  editar(m: Mesa) {
    this.mesa = { ...m };
    this.editando = true;
    this.idEditando = m.idMesa;
    this.cdr.detectChanges();
  }

  eliminar(id: number) {
    if (confirm('¿Eliminar mesa?')) {
      this.service.eliminar(id).subscribe({
        next: () => this.cargar()
      });
    }
  }

  limpiar() {
    this.mesa = { numeroMesa: 0, capacidad: 0 };
    this.editando = false;
    this.idEditando = undefined;
    this.cdr.detectChanges();
  }
}