import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MenuService, Menu } from '../../services/menu';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './menu.html',
  styleUrls: ['./menu.css']
})
export class MenuComponent implements OnInit {
  platos: Menu[] = [];
  plato: Menu = { nombrePlato: '', precio: 0, categoria: '' };
  editando = false;
  idEditando?: number;

  constructor(
    private service: MenuService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.cargar();
  }

  cargar() {
    this.service.listar().subscribe({
      next: (data) => {
        this.platos = [...data];
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }

  guardar() {
    if (this.editando && this.idEditando) {
      this.service.actualizar(this.idEditando, this.plato).subscribe({
        next: () => {
          this.cargar();
          this.limpiar();
        }
      });
    } else {
      this.service.crear(this.plato).subscribe({
        next: () => {
          this.cargar();
          this.limpiar();
        }
      });
    }
  }

  editar(m: Menu) {
    this.plato = { ...m };
    this.editando = true;
    this.idEditando = m.idPlato;
    this.cdr.detectChanges();
  }

  eliminar(id: number) {
    if (confirm('¿Eliminar plato?')) {
      this.service.eliminar(id).subscribe({
        next: () => this.cargar()
      });
    }
  }

  limpiar() {
    this.plato = { nombrePlato: '', precio: 0, categoria: '' };
    this.editando = false;
    this.idEditando = undefined;
    this.cdr.detectChanges();
  }
}