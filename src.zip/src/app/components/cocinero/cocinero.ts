import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CocineroService, Cocinero } from '../../services/cocinero';

@Component({
  selector: 'app-cocinero',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './cocinero.html',
  styleUrls: ['./cocinero.css']
})
export class CocineroComponent implements OnInit {
  cocineros: Cocinero[] = [];
  cocinero: Cocinero = { nombreCocinero: '', turno: '' };
  editando = false;
  idEditando?: number;

  constructor(
    private service: CocineroService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.cargar();
  }

  cargar() {
    this.service.listar().subscribe({
      next: (data) => {
        this.cocineros = [...data];
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }

  guardar() {
    if (this.editando && this.idEditando) {
      this.service.actualizar(this.idEditando, this.cocinero).subscribe({
        next: () => {
          this.cargar();
          this.limpiar();
        }
      });
    } else {
      this.service.crear(this.cocinero).subscribe({
        next: () => {
          this.cargar();
          this.limpiar();
        }
      });
    }
  }

  editar(c: Cocinero) {
    this.cocinero = { ...c };
    this.editando = true;
    this.idEditando = c.idCocinero;
    this.cdr.detectChanges();
  }

  eliminar(id: number) {
    if (confirm('¿Eliminar cocinero?')) {
      this.service.eliminar(id).subscribe({
        next: () => this.cargar()
      });
    }
  }

  limpiar() {
    this.cocinero = { nombreCocinero: '', turno: '' };
    this.editando = false;
    this.idEditando = undefined;
    this.cdr.detectChanges();
  }
}