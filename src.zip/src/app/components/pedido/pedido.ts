import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MenuService, Menu } from '../../services/menu';

@Component({
  selector: 'app-pedido',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './pedido.html',
  styleUrls: ['./pedido.css']
})
export class Pedido implements OnInit {
  platosMenu: Menu[] = [];
  pedidosActivos: any[] = [];

  pedido = {
    mesa: '',
    platos: [] as any[]
  };

  platoSeleccionado = {
    nombre: '',
    cantidad: 1
  };

  constructor(
    private menuService: MenuService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.cargarPlatosDelMenu();
    this.cargarPedidosExistentes();
  }

  cargarPlatosDelMenu() {
    this.menuService.listar().subscribe({
      next: (data) => {
        this.platosMenu = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }

  cargarPedidosExistentes() {
    const guardados = localStorage.getItem('pedidos_vivos');
    if (guardados) {
      this.pedidosActivos = JSON.parse(guardados);
    }
  }

  agregarPlato() {
    const infoPlato = this.platosMenu.find(p => p.nombrePlato === this.platoSeleccionado.nombre);
    
    if (infoPlato && this.platoSeleccionado.cantidad > 0) {
      this.pedido.platos.push({
        nombre: infoPlato.nombrePlato,
        precio: infoPlato.precio,
        cantidad: this.platoSeleccionado.cantidad
      });
      
      this.platoSeleccionado = { nombre: '', cantidad: 1 };
      this.cdr.detectChanges();
    }
  }

  eliminarPlato(index: number) {
    this.pedido.platos.splice(index, 1);
    this.cdr.detectChanges();
  }

  guardarComanda() {
    if (this.pedido.mesa && this.pedido.platos.length > 0) {
      this.pedidosActivos.push({ ...this.pedido });
      localStorage.setItem('pedidos_vivos', JSON.stringify(this.pedidosActivos));
      
      alert('Pedido enviado a cocina');
      this.pedido = { mesa: '', platos: [] };
      this.cdr.detectChanges();
    }
  }
}