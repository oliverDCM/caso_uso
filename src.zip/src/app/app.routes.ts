import { Routes } from '@angular/router';
import { ClienteComponent } from './components/cliente/cliente';
import { MesaComponent } from './components/mesa/mesa';
import { CocineroComponent } from './components/cocinero/cocinero';
import { MenuComponent } from './components/menu/menu';
import { Pedido } from './components/pedido/pedido';
import { FacturaComponent } from './components/factura/FacturaComponent';

export const routes: Routes = [
  { path: '', redirectTo: 'clientes', pathMatch: 'full' },
  { path: 'clientes', component: ClienteComponent },
  { path: 'mesas', component: MesaComponent },
  { path: 'cocineros', component: CocineroComponent },
  { path: 'menu', component: MenuComponent },
  { path: 'pedidos', component: Pedido },
  { path: 'facturas', component: FacturaComponent },
];