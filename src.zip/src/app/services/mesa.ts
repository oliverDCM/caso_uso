import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Mesa {
  idMesa?: number;
  numeroMesa: number;
  capacidad: number;
}

@Injectable({ providedIn: 'root' })
export class MesaService {
  private url = '/api/mesas';
  constructor(private http: HttpClient) {}

  listar(): Observable<Mesa[]> { return this.http.get<Mesa[]>(this.url); }
  crear(m: Mesa): Observable<Mesa> { return this.http.post<Mesa>(this.url, m); }
  actualizar(id: number, m: Mesa): Observable<Mesa> { return this.http.put<Mesa>(`${this.url}/${id}`, m); }
  eliminar(id: number): Observable<void> { return this.http.delete<void>(`${this.url}/${id}`); }
}