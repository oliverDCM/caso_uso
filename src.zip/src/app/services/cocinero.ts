import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Cocinero {
  idCocinero?: number;
  nombreCocinero: string;
  turno: string;
}

@Injectable({ providedIn: 'root' })
export class CocineroService {
  private url = '/api/cocineros';
  constructor(private http: HttpClient) {}

  listar(): Observable<Cocinero[]> { return this.http.get<Cocinero[]>(this.url); }
  crear(c: Cocinero): Observable<Cocinero> { return this.http.post<Cocinero>(this.url, c); }
  actualizar(id: number, c: Cocinero): Observable<Cocinero> { return this.http.put<Cocinero>(`${this.url}/${id}`, c); }
  eliminar(id: number): Observable<void> { return this.http.delete<void>(`${this.url}/${id}`); }
}