import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Menu {
  idPlato?: number;
  nombrePlato: string;
  precio: number;
  categoria: string;
}

@Injectable({ providedIn: 'root' })
export class MenuService {
  private url = '/api/menu';
  constructor(private http: HttpClient) {}

  listar(): Observable<Menu[]> { return this.http.get<Menu[]>(this.url); }
  crear(m: Menu): Observable<Menu> { return this.http.post<Menu>(this.url, m); }
  actualizar(id: number, m: Menu): Observable<Menu> { return this.http.put<Menu>(`${this.url}/${id}`, m); }
  eliminar(id: number): Observable<void> { return this.http.delete<void>(`${this.url}/${id}`); }
}