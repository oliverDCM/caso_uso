import { TestBed } from '@angular/core/testing';

import { Cocinero } from './cocinero';

describe('Cocinero', () => {
  let service: Cocinero;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Cocinero);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
