import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Cliente {
  idCliente?: number;
  nombreCliente: string;
  telefono: string;
}

@Injectable({ providedIn: 'root' })
export class ClienteService {
  private url = '/api/clientes';
  constructor(private http: HttpClient) {}

  listar(): Observable<Cliente[]> { return this.http.get<Cliente[]>(this.url); }
  crear(c: Cliente): Observable<Cliente> { return this.http.post<Cliente>(this.url, c); }
  actualizar(id: number, c: Cliente): Observable<Cliente> { return this.http.put<Cliente>(`${this.url}/${id}`, c); }
  eliminar(id: number): Observable<void> { return this.http.delete<void>(`${this.url}/${id}`); }
}